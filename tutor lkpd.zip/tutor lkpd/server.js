import express from 'express';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const app = express();
app.use(express.json());
app.use(express.static('public'));

const ai = new GoogleGenAI();

const SYSTEM_INSTRUCTION_LKPD = `
Anda adalah Tutor Pendamping LKPD (Lembar Kerja Peserta Didik) yang ramah, interaktif, dan edukatif.

TUGAS UTAMA:
Membantu siswa memahami dan menyelesaikan soal/tugas di LKPD mereka.

ATURAN MUTLAK (JANGAN DILANGGAR):
1. DILARANG KERAS memberikan jawaban akhir, solusi langsung, atau hasil perhitungan akhir dari soal yang ditanyakan siswa.
2. JIKA SISWA MEMINTA JAWABAN: Tolak dengan sopan, lalu berikan petunjuk awal atau konsep dasar yang relevan.
3. GUNAKAN METODE SOKRATES: Ajukan pertanyaan pancingan sederhana yang mengarahkan siswa untuk menemukan jawabannya sendiri langkah demi langkah.
4. JIKA SISWA SALAH: Jelaskan di mana letak kekeliruan konsepnya (bukan jawabannya), lalu berikan contoh sederhana lain.
5. JIKA SISWA BENAR: Berikan pujian ringkas dan dorong mereka untuk melanjutkan ke langkah/soal berikutnya.
`;

const sessions = new Map();

app.post('/api/chat', async (req, res) => {
  try {
    const { message, sessionId } = req.body;

    if (!message || !sessionId) {
      return res.status(400).json({ error: 'Pesan dan sessionId wajib diisi.' });
    }

    let chat = sessions.get(sessionId);
    if (!chat) {
      chat = ai.chats.create({
        model: 'gemini-2.5-flash',
        config: {
          systemInstruction: SYSTEM_INSTRUCTION_LKPD,
          temperature: 0.3,
        },
      });
      sessions.set(sessionId, chat);
    }

    const response = await chat.sendMessage({ message });
    res.json({ reply: response.text });
  } catch (error) {
    console.error('Error:', error);
    res.status(500).json({ error: 'Terjadi kesalahan pada server.' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server Tutor LKPD berjalan di http://localhost:${PORT}`);
});
export default app;